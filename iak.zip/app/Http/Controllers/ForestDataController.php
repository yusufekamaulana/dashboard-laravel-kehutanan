<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ForestDataController extends Controller
{
    public function index()
    {
        // Fetch forest data
        $forestData = DB::table('luas_hutan')
            ->select('kode_pulau', 'hutan_lindung', 'suaka_alam', 'hutan_produksi_terbatas', 'hutan_produksi_tetap', 'hutan_konservasi', 'luas_hutan_dan_perairan')
            ->get();

        return view('welcome', compact('forestData'));
    }
}
