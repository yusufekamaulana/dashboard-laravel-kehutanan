<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ForestAreaController extends Controller
{
    public function index()
    {
        // Fetch forest data
        $forestData = DB::table('luas_hutan')
            ->select('kode_pulau', 'hutan_lindung', 'suaka_alam', 'hutan_produksi_terbatas', 'hutan_produksi_tetap', 'hutan_konservasi', 'luas_hutan_dan_perairan','konservasi_perairan','konservasi_daratan')
            ->get();

            return view('forest.index', compact('forestData'));
    }
}