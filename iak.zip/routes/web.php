<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ForestDataController;
use App\Http\Controllers\ForestAreaController;

Route::get('/', [ForestDataController::class, 'index']);

Route::get('/forest-area', [ForestAreaController::class, 'index']);

